<?php
   include("connection.php");
//    print_r($_FILES);
//  print_r($_POST);die;
    $name = mysqli_real_escape_string($conn, $_POST['firstName'] . " " . $_POST['lastName']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $image= mysqli_real_escape_string($conn, $_FILES['image']['name']);
    
   if(mysqli_query($conn, "INSERT INTO user(name, email, image) VALUES('" . $name . "', '" . $email . "', '" . $image . "')")) {
    echo '1';
   } else {
      echo "Error: " . $sql . "" . mysqli_error($conn);
   }
   mysqli_close($conn);

 
 
?>