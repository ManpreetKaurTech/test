<!DOCTYPE html>
<html>
<head>
    <title>Ajax POST request with JQuery and PHP - Tutsmake</title>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.js"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <style type="text/css">
        body {
            font-family: calibri;
        }
        .box {
            margin-bottom: 10px;
        }
        .box label {
            display: inline-block;
            width: 80px;
            text-align: right;
            margin-right: 10px;
        }
        .box input, .box textarea {
            border-radius: 3px;
            border: 1px solid #ddd;
            padding: 5px 10px;
        }
        .btn-submit {
            margin-left: 90px;
        }
    </style>
</head>
<body>
    <h2>Test Task </h2>
    <form id="newform" action="action.php" method="post" enctype="multipart/form-data">
    <span id="captcha-error" style="color:green;"></span>
        <div class="box">
            <label>First Name:</label><input type="text" name="firstName" id="firstName" />
        </div>
        <div class="box">
            <label>Last Name:</label><input type="text" name="lastName" id="lastName" />
        </div>
        <div class="box">
            <label>Email:</label><input type="email" name="email" id="email" />
        </div>
        <div class="box">
            <label>image:</label><input id="uploadImage" type="file" accept="image/*" name="image"  id="image"/>
        </div>
        <div class="box">
            <div class="g-recaptcha" data-sitekey="6LdIQishAAAAAPVBQKg57XXI3VppilHc_l5Z2pvd"></div>
            <span id="captcha-error" style="color:red;"></span>
        </div>
        
        <input type="submit" class="btn-submit" value="Submit" />
    </form>
    <script>
        

        $(document).ready(function() {


            $(document).ready(function () {

             $('#newform').validate({ // initialize the plugin
                rules: {
                    firstName: {
                        required: true,
                        maxlength: 20
                    },
                    lastName: {
                        required: true,
                        maxlength: 20
                    },
                    email: {
                        required: true,
                        email: true
                    },
                    image: {
                        required: true,
                        extension: "jpg|jpeg|png|ico|bmp"
                    },
                
                },
                messages: {
                    image: {
                        extension: "Please upload file in these format only (jpg, jpeg, png, ico, bmp).",
                        required: "image field is Required."
                    }
                },
                submitHandler: function(form) {
                    var formData = new FormData(form)
                    if(grecaptcha.getResponse() == "") {
                        $('#captcha-error').html("You can't proceed! recaptcha validation faild");
                        return;
                    }
                    $('#captcha-error').html('');
                    $.ajax({
                        type: "POST",
                        url: "action.php",
                        cache: false,
                        contentType: false,
                        processData: false,
                        data: formData,
                        success: function(data) {
                            console.log(data);
                            $('#captcha-error').html('Thank you form successfully submit');

                        },
                        error: function(xhr, status, error) {
                            console.error(xhr);
                        }
                    });
                }       
            });

            });
 

        });
    </script>
</body>
</html>
